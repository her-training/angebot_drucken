<?php
return [

    /*
    |--------------------------------------------------------------------------
    | Settings
    |--------------------------------------------------------------------------
    |
    | Set some default values. It is possible to add all defines that can be set
    | in dompdf_config.inc.php. You can also override the entire config file.
    |
    */
    'tarifs' => [
        'start_packet' => 99,
        'month' => ['1' => 1, '6' => 6, '12' => 12, '24' => 24],
        'karten' => ['ems10' => 300, 'ems30' => 700],
        '1' => ['start' => 99, 'pro_6' => 10, 'pro_4' => 10, 'drink' => 25, 'locker' => 20, 'towel' => 30, 'lock_towel' => 40, 'solarium' => 20, 'pers_tr_4' => 90, 'pers_tr_8' => 150],
        '6' => ['start' => 79, 'pro_6' => 10, 'pro_4' => 10, 'drink' => 20, 'locker' => 15, 'towel' => 25, 'lock_towel' => 30, 'solarium' => 15, 'pers_tr_4' => 55, 'pers_tr_8' => 95],
        '12' => ['start' => 69, 'pro_6' => 10, 'pro_4' => 10, 'drink' => 20, 'locker' => 15, 'towel' => 25, 'lock_towel' => 30, 'solarium' => 15, 'pers_tr_4' => 55, 'pers_tr_8' => 55],
        '24' => ['start' => 59, 'pro_6' => 10, 'pro_4' => 10, 'drink' => 20, 'locker' => 15, 'towel' => 25, 'lock_towel' => 30, 'solarium' => 15, 'pers_tr_4' => 55, 'pers_tr_8' => 95]
    ]

];