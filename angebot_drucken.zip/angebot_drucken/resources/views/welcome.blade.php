<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Lgkauto') }}</title>
    <!-- Scripts -->
    <script src="{{ asset('js/jquery.min.js')}}"></script>
    <script src="{{ asset('js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{ asset('js/blockui.min.js')}}"></script>
    <script src="{{ asset('js/d3.min.js')}}"></script>
    <script src="{{ asset('js/d3_tooltip.js')}}"></script>
    <script src="{{ asset('js/select2.min.js')}}"></script>
    <script src="{{ asset('js/uniform.min.js')}}"></script>
    <script src="{{ asset('js/form_inputs.js')}}"></script>
    <script src="{{ asset('js/interactions.min.js') }}"></script>
    <script src="{{ asset('js/form_select2.js') }}"></script>
    <script src="{{ asset('js/purify.min.js') }}"></script>
    <script src="{{ asset('js/sortable.min.js') }}"></script>
    <script src="{{ asset('js/fileinput.min.js') }}"></script>
    <script src="{{ asset('js/uploader_bootstrap.js') }}"></script>
    <script src="{{ asset('js/switchery.min.js') }}"></script>
    <script src="{{ asset('js/touchspin.min.js') }}"></script>
    <script src="{{ asset('js/form_input_groups.js') }}"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Styles -->
    <link href="{{asset('css/bootstrap.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/icomoon/styles.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/bootstrap_limitless.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/layout.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/components.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/colors.css')}} " rel="stylesheet" type="text/css">
</head>
<body>
<div class="container">
    <form method="post" action="" id="form1">
        <div class="form-group">
            <h2>Aufnahmegebühr/Вступительный взнос 99 EURO</h2>
            <label>Months</label>
            <select class="form-control select months" data-fouc>
                <option value="1">1</option>
                <option value="6">6</option>
                <option value="12">12</option>
                <option value="24">24</option>
            </select>
        </div>
        <div>
            <p>Gerate</p>
            <p>Sauna</p>
            <p>Kurse</p>
        </div>
        <p class="start">Monthly:<span class="total" style="color: #1b8054;font-size: 36px;">99</span>Total:<span class="total_y" style="color: #1b8054;font-size: 36px;">99</span></p>
        <input type="hidden" class="start" value="99" name="start">
        <label class="col-form-label col-lg-2">6 Monate Stilllegung pro Jahr </label>
        <div class="input-group-text">10 euro
            <input type="checkbox" class="form-control-styled" id="freeze" name="input-addon-checkbox"  data-fouc class="freeze">
        </div>
        <label class="col-form-label col-lg-2"> 4x Personal Training pro Jahr</label>
        <div class="input-group-text">10 euro
            <input type="checkbox" class="form-control-styled" id="freeze" name="input-addon-checkbox"  data-fouc class="freeze">
        </div>
        <h2>Add options</h2>
        <label class="col-form-label col-lg-2">Drink</label>
        <input type="checkbox" class="form-control-styled" id="drink" name="input-addon-checkbox"  data-fouc>
        <label class="col-form-label col-lg-2">Locker</label>
        <input type="checkbox" class="form-control-styled" id="locker" name="input-addon-checkbox"  data-fouc>
        <label class="col-form-label col-lg-2">Towel</label>
        <input type="checkbox" class="form-control-styled" id="towel" name="input-addon-checkbox"  data-fouc>
        <label class="col-form-label col-lg-2">Lock Towel</label>
        <input type="checkbox" class="form-control-styled " id="lock_towel" name="input-addon-checkbox"  data-fouc>
        <label class="col-form-label col-lg-2">Solarium</label>
        <input type="checkbox" class="form-control-styled" id="solarium" name="input-addon-checkbox"  data-fouc>
        <label class="col-form-label col-lg-2">Personal Trainin 4</label>
        <input type="checkbox" class="form-control-styled" id="pers_tr_4" name="input-addon-checkbox"  data-fouc>
        <label class="col-form-label col-lg-2">Personal Trainin 8</label>
        <input type="checkbox" class="form-control-styled" id="pers_tr_8" name="input-addon-checkbox"  data-fouc>
        <p> New Total:<span class="total1" style="color: #1b8054;font-size: 36px;"></span></p>
    </form>
</div>
<a class="btn" href="{{route('getpdf')}}">pdf</a>


<script>
    $( document ).ready(function() {
        var tarrif={
            '1':{'start':79,'freeze':10,'drink':20,'locker':15,'towel':25,'lock_towel':30,'solarium':15,'pers_tr_4':55,'pers_tr_8':95},
            '6':{'start':79,'freeze':10,'drink':20,'locker':15,'towel':25,'lock_towel':30,'solarium':15,'pers_tr_4':55,'pers_tr_8':95},
            '12':{'start':69,'freeze':10,'drink':20,'locker':15,'towel':25,'lock_towel':30,'solarium':15,'pers_tr_4':55,'pers_tr_8':55},
            '24':{'start':59,'freeze':10,'drink':20,'locker':15,'towel':25,'lock_towel':30,'solarium':15,'pers_tr_4':55,'pers_tr_8':95}
        }
        var m='1';
        var ajax_data={};
        var start_val=99;

        $( "#form1" ).on('change','.months',function() {
            $(".uniform-checker span").removeClass( "checked" );
            m=$(this).val();
            $('.total').html(tarrif[m]['start']);
            $('.start').val(tarrif[m]['start']);
            start_val=tarrif[m]['start'];

        });
        var options=$("input[name='input-addon-checkbox']");
        options.click(function(){

            var id=$(this).attr('id');
            ajax_data[id]=tarrif[m][id];
            start_val += tarrif[m][id] ;
            $('.total1').html(start_val);
        });
        console.log(ajax_data);
    });
</script>
{{--function disablebtn(sel){--}}
{{--$(sel).addClass('btn-disabled');--}}
{{--$(sel).attr('disabled', 'disabled');--}}
{{--$(sel).prop('disabled', true);--}}
{{--}--}}
{{--disablebtn('.month');--}}
{{--disablebtn('.period');--}}
{{--var options=$(".options .category");--}}
{{--options.removeClass('active');--}}
{{--var tarrif={--}}
{{--'1':<?=json_encode($tarif['1'])?>,--}}
{{--'6':<?=json_encode($tarif['6'])?>,--}}
{{--'12':<?=json_encode($tarif['12'])?>,--}}
{{--'24':<?=json_encode($tarif['24'])?>--}}
{{--}--}}
{{--var m='1';--}}
{{--$( "#form1" ).on('change','.months',function() {--}}
{{--m=$(this).val();--}}
{{--$('.total').html(tarrif[m]['start']*(+m)+' €');--}}
{{--$('.start').val(tarrif[m]['start']*(+m));--}}
{{--});--}}
{{--options.on('click',function(){--}}
{{--var ajax_data=[];--}}
{{--$(this).toggleClass('active');--}}
{{--if(m!=='1'){--}}
{{--$('.period').removeAttr('disable');--}}
{{--if( $(this).hasClass('period') && $('.month').hasClass('active')){--}}
{{--$('.month').removeClass('active');--}}
{{--}--}}
{{--else if( $(this).hasClass('month') && $('.period').hasClass('active')){--}}
{{--$('.period').removeClass('active');--}}
{{--}--}}

{{--}--}}
{{--var opts=$('.active');--}}
{{--opts.each(function () {--}}
{{--ajax_data.push(this.name);--}}
{{--this.value=tarrif[m][this.name];--}}
{{--})--}}
{{--console.log( ajax_data);--}}
{{--});--}}
</body>
</html>