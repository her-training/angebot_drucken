<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
          integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Angebot Drucken</title>
    <link href="{{asset('css/style.css')}}" rel="stylesheet">
</head>
<body>
<div class="text-center">
    <img src="/img/citylife-sportsclub.png" alt="" width="150">
</div>
<form class="form" action="javascript:void(0)" id="form1" method="post">
    {{ csrf_field() }}
    <div class="select-main d-flex align-items-center">
        <strong>Laufzet</strong>
        <select name="months" class="months">
            @foreach($months as $month)
                <option value="{{$month}}">{{$month}} Monate</option>
            @endforeach
        </select>
    </div>
    <div class="d-flex justify-content-between ">
        <div class="include">
            Gerate
        </div>
        <div class="include">
            Sauna
        </div>
        <div class="include">
            Kurse
        </div>
    </div>
    <div class="price-first">
        <span class="total">{{$tarif['1']['start']}} €</span>
    </div>
    <div class="offers options">
        <div class="categories d-flex flex-wrap">
            <div class="freeze1">
                <button type="button" class="category" name="locker">Privater Spind</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period1">
                        Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category opt month" name="options" autocomplete="off" value="month1">
                        Monatlich
                    </label>
                </div>
            </div>
            <div class="freeze2">
                <button type="button" class="category" name="towel">Handtuchservice</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period2">
                        Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category month" name="options" autocomplete="off" value="month2">
                        Monatlich
                    </label>
                </div>
            </div>
            <div class="freeze3">
                <button type="button" class="category" name="lock_towel">Spind + Handtuchservice</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period3">
                        Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category month" name="options" autocomplete="off" value="month3">
                        Monatlich
                    </label>
                </div>
            </div>
            <div class="freeze4">
                <button type="button" class="category" name="drink">10 Freigetranke / Monate</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period4">
                        Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category month" name="options" autocomplete="off" value="month4">
                        Monatlich
                    </label>
                </div>
            </div>
            <div class="freeze5">
                <button type="button" class="category" name="pro_6">6 Monate Stillegung / Jahr</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period5">
                        Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category month" name="options" autocomplete="off" value="month5">
                        Monatlich
                    </label>
                </div>
            </div>
            <div class="freeze6">
                <button type="button" class="category" name="pro_4">4x Pesonal Training / Jahr</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period6">Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category month" name="options" autocomplete="off" value="month6">Monatlich
                    </label>
                </div>
            </div>
            <div class="freeze7">
                <button type="button" class="category" name="solarium">Solariumflatrate</button>
                <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
                    <label class="btn opt">
                        <input type="radio" class="category period" name="options" autocomplete="off" value="period7">Laufzeit
                    </label>
                    <label class="btn opt">
                        <input type="radio" class="category month" name="options" autocomplete="off" value="month7">Monatlich
                    </label>
                </div>
            </div>
        </div>
    </div>
    <div class="person-price d-flex align-items-center">
        <strong>Personlicher <br>Monatsbeintrag</strong>
        <div class="price-second">
            <span>{{$tarif['1']['start']}} €</span>
        </div>
    </div>
    <div class="d-flex justify-content-between ">
        <div class="include">Trainingsplan</div>
        <div class="include">Korper-Check</div>
        <div class="include">Personlicher Ansprechpartner</div>
    </div>
    <div class="person-price-second d-flex align-items-center">
        <strong>Startpaket</strong>
        <div class="price-second ">
            <span>{{$tarif['start_packet']}} €</span>
        </div>
        <span>bis {{$endDate}} 50% Nachlass </span>
    </div>
    <div class="zusa">Zusatzangebot</div>
    <button type="button" class="category special-offer d-flex justify-content-between" name="ems10">
        <div class="special-name">10 x EMS oder Personal Training*</div>
        <div class="special-price d-flex align-items-center">
            <span>300€</span>
            <span>450€</span>
        </div>
    </button>
    <button type="button" class="category special-offer d-flex justify-content-between" name="ems30">
        <div class="special-name">30 x EMS oder Personal Training*</div>
        <div class="special-price d-flex align-items-center">
            <span>700€</span>
            <span>1000€</span>
        </div>
    </button>

    <div class="person-price-second d-flex align-items-center">
        <strong>Total</strong>
        <div class="price-second total-pack">
            <span>{{$tarif['start_packet']}} €</span>
        </div>
    </div>
    <button type="submit" class="zusa">Angebot drucken</button>
</form>
<a href="{{route('getpdf1')}}">pdf</a>
<script src="{{ asset('js/jquery.min.js')}}"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
        crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {
        disablebtn('.month');
        disablebtn('.period');
        var months = '1';
        var ajax_data = [];
        $('.months').change(function () {
            months = $(this).val();
            activopt('[class ^= "freeze"]');
            var opts = $('.active');
            opts.each(function () {
                if (this.name) {
                    ajax_data.push(this.name);
                }
                else {
                    ajax_data.push($(this).find('input').val());
                }
            })
            ajax_data = jQuery.grep(ajax_data, function (value) {
                return value != 'options';
            });
            ajax_data = ajax_data.length ? ajax_data : [];
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "GET",
                url: '/standart_total/ajax_data/' + months,
                data: {data: JSON.stringify(ajax_data)},
                success: function (response) {
                    $('.total').html(response.standart_total + ' € ');
                    $('.person-price .price-second span').html(response.result + ' € ');
                    $('.total-pack span').html(response.total_pack + ' € ');
                    $('.total-pack span').html(response.result_special + ' € ');
                    console.log(response);
                    ajax_data = [];
                }
            });
        });


        $('.category').click(function () {
            var months = $("[name='months']").val();
            $(this).toggleClass('active');
            activopt('.freeze1');
            activopt('.freeze2');
            activopt('.freeze3');
            activopt('.freeze4');
            activopt('.freeze5');
            activopt('.freeze6');
            activopt('.freeze7');
            var opts = $('.active');
            opts.each(function () {
                if (this.name) {
                    ajax_data.push(this.name);
                }
                else {
                    ajax_data.push($(this).find('input').val());
                }
            })
            ajax_data = jQuery.grep(ajax_data, function (value) {
                return value != 'options';
            });
            ajax_data = ajax_data.length ? ajax_data : [];

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "post",
                url: '/standart_total/ajax_data/' + months,
                data: {data: JSON.stringify(ajax_data)},
                success: function (response) {
                    $('.person-price .price-second span').html(response.result + ' € ');
                    $('.total-pack span').html(response.total_pack + ' € ');
                    $('.total-pack span').html(response.result_special + ' € ');
                    ajax_data = [];
                }
            });
        });
        $('.zusa').click(function (e) {
            e.preventDefault();
            var months = $("[name='months']").val();
            var opts = $('.active');
            opts.each(function () {
                if (this.name) {
                    ajax_data.push(this.name);
                }
                else {
                    ajax_data.push($(this).find('input').val());
                }
            })
            ajax_data = jQuery.grep(ajax_data, function (value) {
                return value != 'options';
            });
            ajax_data = ajax_data.length ? ajax_data : [];

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "post",
                url: '/getangebot/' + months,
                data: {data: JSON.stringify(ajax_data)},
                success: function (response) {
                    console.log(response);
                    // ajax_data = [];
                }
            });
        });

        function disablebtn(sel) {
            $(sel).addClass('btn-disabled');
            $(sel).attr('disabled', 'disabled');
            $(sel).prop('disabled', true);
        }

        function enablebtn(sel) {
            $(sel).removeClass('btn-disabled');
            $(sel).removeAttr('disabled');
            $(sel).prop('disabled', false);
        }

        function activopt(sel) {
            if ($(sel).find('button').hasClass('active')) {
                if (months == 1) {
                    enablebtn(sel + ' .month');
                    disablebtn(sel + ' .period');

                }
                else {
                    enablebtn(sel + ' .month');
                    enablebtn(sel + ' .period');
                }
            }
            else {
                disablebtn(sel + ' .month');
                disablebtn(sel + ' .period');
                $(sel + ' .period').parent('.opt').removeClass('active');
                $(sel + ' .month').parent('.opt').removeClass('active');
            }
        }
    })
</script>

</body>
</html>