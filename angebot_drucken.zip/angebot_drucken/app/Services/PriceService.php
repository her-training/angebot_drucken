<?php

namespace App\Services;

/**
 * Created by PhpStorm.
 * User: Aist
 * Date: 18.09.2020
 * Time: 14:27
 */
class PriceService
{
    /**
     * @param $months
     * @return \Illuminate\Config\Repository|mixed
     */
    public function calculate_total_standart($months)
    {
        return config("calc.tarifs.$months.start")*$months;
    }

    /**
     * @param $opts
     * @return \Illuminate\Config\Repository|mixed
     */
    public function calculate_total_opt($opts)
    {
       // return config("calc.tarifs.$months.start")*$months;
    }

}