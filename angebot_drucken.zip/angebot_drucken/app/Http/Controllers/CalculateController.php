<?php

namespace App\Http\Controllers;

//use App\Services\PriceService;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Http\Request;


class CalculateController extends Controller
{

    public $result;
    public $months='1';
    public function index()
    {
        $config = config('calc.tarifs');
//        $m='6';
//        dd(config("calc.tarifs.$m.freeze1"));
        $ends = date('Y.m.d h:i', strtotime('now + 3 days'));
        $this->months = config('calc.tarifs.month');
        return view('index', ['tarif' => $config, 'endDate' => $ends, 'months' => $this->months]);
    }

    public function getAngebot(Request $request,$months)
    {
        $data = json_decode($request->get('data'));
//        $ends = date('Y.m.d h:i', strtotime('now + 3 days'));
//       // dd($data);
//        $pdf = PDF::loadView('pdf');
//        return response()->download('invoice.pdf');

    }
    public function getPdf()
    {
        $pdf = PDF::loadView('pdf');
        return $pdf->download('invoice.pdf');

    }



    public function getTotalAjax(Request $request,$months)
    {
        $this->months=$months;
        $this->result = calculate_total_standart($this->months);
        $data = json_decode($request->get('data'));
        $result_tot = config("calc.tarifs.$this->months.start") * $this->months;
        //dd($data);
        if (in_array('locker', $data) && in_array('month1', $data)) {
            $result_tot += config("calc.tarifs.$this->months.locker");
        } else if (in_array('locker', $data) && in_array('period1', $data)) {
            $result_tot += config("calc.tarifs.$this->months.locker") * $this->months;
        }
        if (in_array('towel', $data) && in_array('month2', $data)) {
            $result_tot += config("calc.tarifs.$this->months.towel");
        } else if (in_array('towel', $data) && in_array('period2', $data)) {
            $result_tot += config("calc.tarifs.$this->months.towel") * $this->months;
        }

        if (in_array('lock_towel', $data) && in_array('month3', $data)) {
            $result_tot += config("calc.tarifs.$this->months.towel");
        } else if (in_array('lock_towel', $data) && in_array('period3', $data)) {
            $result_tot += config("calc.tarifs.$this->months.lock_towel") * $this->months;
        }

        if (in_array('drink', $data) && in_array('month4', $data)) {
            $result_tot += config("calc.tarifs.$this->months.drink");
        } else if (in_array('drink', $data) && in_array('period4', $data)) {
            $result_tot += config("calc.tarifs.$this->months.drink") * $this->months;
        }
        if (in_array('drink', $data) && in_array('month4', $data)) {
            $result_tot += config("calc.tarifs.$this->months.drink");
        } else if (in_array('drink', $data) && in_array('period4', $data)) {
            $result_tot += config("calc.tarifs.$this->months.drink") * $this->months;
        }
        if (in_array('pro_6', $data) && in_array('month5', $data)) {
            $result_tot += config("calc.tarifs.$this->months.pro_6");
        } else if (in_array('pro_6', $data) && in_array('period5', $data)) {
            $result_tot += config("calc.tarifs.$this->months.pro_6") * $this->months;
        }
        if (in_array('pro_4', $data) && in_array('month6', $data)) {
            $result_tot += config("calc.tarifs.$this->months.pro_4");
        } else if (in_array('pro_4', $data) && in_array('period6', $data)) {
            $result_tot += config("calc.tarifs.$this->months.pro_4") * $this->months;
        }
        if (in_array('solarium', $data) && in_array('month7', $data)) {
            $result_tot += config("calc.tarifs.$this->months.solarium");
        } else if (in_array('solarium', $data) && in_array('period6', $data)) {
            $result_tot += config("calc.tarifs.$this->months.solarium") * $this->months;
        }

        $result_special=$result_tot;
        $result_special += in_array('ems10', $data) ? config("calc.tarifs.karten.ems10"): 0;
        $result_special += in_array('ems30', $data) ? config("calc.tarifs.karten.ems30"): 0;
        return response()->json(array('result' => $result_tot, 'months' => $this->months,'standart_total'=>$this->result,'total_pack'=>$result_tot,'result_special'=> $result_special+99));
    }







}
