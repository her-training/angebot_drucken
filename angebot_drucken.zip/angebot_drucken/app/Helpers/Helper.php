<?php

function calculate_total_standart($months)
{
    return config("calc.tarifs.$months.start")*$months;
}

function calculate_total_opt($opts=0,$months)
{

}
