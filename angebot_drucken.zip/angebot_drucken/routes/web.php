<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'CalculateController@index')->name('index');
Route::post('/getangebot/{months}', 'CalculateController@getAngebot')->name('getpdf');
Route::get('/getpdf', 'CalculateController@getPdf')->name('getpdf1');
//Route::get('/pdf',function(){
//    return view('pdf');
//});
Route::get('/standart_total/ajax_data/{months}', 'CalculateController@getTotalAjax');
Route::post('/standart_total/ajax_data/{months}', 'CalculateController@getTotalAjax');